from django.shortcuts import render, HttpResponse, redirect
from .forms import DocumentForm
from .models import Document

def greet(request):
    return render(request, 'app1/base.html')
    


def uploadFile(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse('success')
    else:
        form = DocumentForm()
    return render(request, 'app1/uploadFile.html', {'form': form })


def search(request):
    if request.method == 'POST':
        search_string = request.POST['query']
        objs = Document.objects.filter(project_title__contains=search_string)
        return render(request, 'app1/searchresult.html',{'objs':objs})
    return render(request, 'app1/search.html')

def list(request):
    objs = Document.objects.all()
    return render(request, 'app1/searchresult.html',{'objs':objs})
    